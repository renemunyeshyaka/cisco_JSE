# cisco_JSE
# Prepared by Jean René MUNYESHYAKA

Dear CISCO JSE trainees

I'm writing to inform your that, all assignment from our course Java Script Essentials and any other Java Script course that may follow in the coming days; shall be uploaded using github.com to this repository. Take time to read the read me file to know the current assignment. Now, you need to fork my account and clone the cisco_JSE repository ...to your computer. In that folder you'll place locally all your CISCO JSE assignments (offline) and push to the remote (upload) when you're ready to submit.

The first assignment to be upload here, will be:

1. 3.0.10 SECTION PRACTICE (to be done by the next week)
